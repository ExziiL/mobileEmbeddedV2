import React, { Component } from "react";
class Header extends Component {

    render() {
        return (
           <center> <h2 className="jumbotron">Robot Control Console</h2> </center>
        );
    }
}

export default Header;